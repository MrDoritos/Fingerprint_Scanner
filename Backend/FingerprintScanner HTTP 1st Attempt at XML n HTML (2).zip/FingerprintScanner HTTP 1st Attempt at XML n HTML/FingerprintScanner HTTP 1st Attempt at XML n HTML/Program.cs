﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Web;
using System.Net.Sockets;
using System.Net;
using System.Net.Http;
using System.IO;

namespace FingerPrintScannerBackend
{
    class Program
    {
        static public TcpListener TcpListener;

        static public List<FingerAccount> fingerAccounts = new List<FingerAccount>();
        
        static public string[] mainMenuItems = new string[] { "View Keys", "Add Key", "Log In", "Log Out", "Use existing finger"};

        static public string HostName = "iansweb.org";
        static public ushort Port = 8080;

        static void Main(string[] args)
        {
            Console.WriteLine($"HostName: {HostName}");
            Console.WriteLine($"Port: {Port}");
            Task.Run(StartWebServer);
            while (true)
            {
                string choice = Log.QueryMultiChoice("Main Menu", mainMenuItems.ToList());
                if (choice == mainMenuItems[0])
                {
                    //View keys
                    foreach (var fingeraccount in fingerAccounts)
                    {
                        Console.WriteLine($"{fingeraccount.Name}, {fingeraccount.loggedIn}");
                    }
                }
                else if (choice == mainMenuItems[1])
                {
                    //Add key
                    var newuser = new FingerAccount(Log.Query("User's Name", ("user" + (fingerAccounts.Count + 1).ToString())));
                    DirectoryInfo directoryInfo = new DirectoryInfo(".");
                    newuser.AddScan(new System.Drawing.Bitmap(Log.QueryMultiChoice("Source bitmap?", directoryInfo.EnumerateFiles().Where(n => n.Name.EndsWith(".bmp")).Select(n => n.Name).ToList())));
                    fingerAccounts.Add(newuser);
                } else if (choice == mainMenuItems[2])
                {
                    //Log In
                    var users = fingerAccounts.Where(n => !(n.loggedIn));
                    if (users.Count() > 0)
                    {
                        string user = Log.QueryMultiChoice("User to log in?", users.Select(n => n.Name).ToList());
                        var matches = fingerAccounts.Where(n => n.Name == user && !(n.loggedIn));
                        if (matches.Count() > 0)
                        {
                            Console.WriteLine($"Logged in the first account that has the name of {matches.First().Name}");
                            matches.First().LogIn();
                        }
                        else
                        {
                            Console.WriteLine("No matches found");
                        }
                    }
                    else
                    {
                        Console.WriteLine("No users are logged out");
                    }
                } else if (choice == mainMenuItems[3])
                {
                    //Log Out
                    var users = fingerAccounts.Where(n => n.loggedIn);
                    if (users.Count() > 0)
                    {
                        string user = Log.QueryMultiChoice("User to log out?", users.Select(n => n.Name).ToList());
                        var matches = fingerAccounts.Where(n => n.Name == user && n.loggedIn);
                        if (matches.Count() > 0)
                        {
                            Console.WriteLine($"Logged out the first account that has the name of {matches.First().Name}");
                            matches.First().LogOut();
                        }
                        else
                        {
                            Console.WriteLine("No matches found");
                        }
                    }
                    else
                    {
                        Console.WriteLine("No users are logged in");
                    }
                } else if (choice == mainMenuItems[4])
                {
                    if (fingerAccounts.Count > 0)
                    {
                        DirectoryInfo directoryInfo = new DirectoryInfo(".");
                        System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(new System.Drawing.Bitmap(Log.QueryMultiChoice("Source bitmap?", directoryInfo.EnumerateFiles().Where(n => n.Name.EndsWith(".bmp")).Select(n => n.Name).ToList())));
                        var finger = FingerOperations.GetFingerAccount(bitmap, fingerAccounts);
                        Console.WriteLine($"{finger.Name}, {finger.loggedIn}");
                    }
                    else
                    {
                        Console.WriteLine("No fingers for comparison!");
                    }
                }
            }            
        }

        static public void UpdateXML()
        {

        }

        public static async Task StartWebServer()
        {
            try
            {
                TcpListener = new TcpListener(new IPEndPoint(Dns.GetHostAddresses(HostName)[0], Port));
                TcpListener.Start();
                await Task.Run(() => Listener(TcpListener));
            }
            catch (Exception e)
            {
                Console.WriteLine($"Listener could not start: \n{e.Message}");
            }
        }

        public static async Task Listener(TcpListener socket)
        {
            while (true)
            {                
                try
                {
                    var client = socket.AcceptTcpClient();
                    Console.WriteLine($"New client {client.Client.RemoteEndPoint.ToString()}");
                    await Task.Run(() => SocketHandler(client));
                } catch(Exception e)
                {
                    Log.Error("Client caused exception", e);
                }
            }
        }

        public static async Task SocketHandler(TcpClient client)
        {
            NetworkStream stream;
            //client.Disconnect(false);
            try
            {
                stream = client.GetStream();
                await SendHTML(stream);
                //stream.Flush();
                //stream.Close();
                //client.Client.Disconnect(false);
                //client.Client.Close();
                client.Close();
                Console.WriteLine("Sent Data");
                //stream.Flush();
                //stream.Close();
                ////client.Close();
                //while (true)
                //{
                //    byte[] buffer = new byte[client.ReceiveBufferSize];
                //    stream.Read(buffer, 0, buffer.Length);
                //    Console.WriteLine($"Recieved: {WebUtility.HtmlDecode(Encoding.UTF8.GetString(buffer))}");
                //}
            }     catch(Exception e)
            {
                Console.WriteLine($"A socket was closed: {client.Client.RemoteEndPoint.ToString()}");
            }     
        }

        public static async Task SendHTML(NetworkStream client)
        {
            using (StreamWriter sw = new StreamWriter(client))
            {

                int i;
                byte[] bytes = new byte[256];
                string data;
                while ((i = client.Read(bytes, 0, bytes.Length)) != 0)
                {
                    
                    // Translate data bytes to a ASCII string. 
                    data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);
                    Console.WriteLine(String.Format("Received: {0}", data));

                    // Process the data sent by the client. 
                    data = data.ToUpper();
                    if (data.Split(' ').Any("GET".Equals))
                    {
                        if (data.Split(' ').ToList().IndexOf("GET") < data.Split(' ').Length + 1)
                        {
                            string request = data.Split(' ')[data.Split(' ').ToList().IndexOf("GET") + 1];
                            switch (request)
                            {
                                case "/":
                                    byte[] payLoad = Encoding.UTF8.GetBytes(File.ReadAllText("index.html"));
                                    byte[] header = Encoding.UTF8.GetBytes(WebUtility.HtmlEncode("HTTP/2.0 200 OK\r\ncontent-type: text/html; charset=utf-8\r\ncontent-length: " + payLoad.Length + "\r\n\r\n"));

                                    var buff = header.ToList();
                                    buff.AddRange(payLoad.ToList());
                                    byte[] buffer = buff.ToArray();
                                    //sw.Write(Encoding.UTF8.GetChars(buffer));

                                    sw.Write(Encoding.UTF8.GetChars(header));
                                    sw.Flush();
                                    sw.Write(Encoding.UTF8.GetChars(payLoad));

                                    sw.Flush();
                                    Console.WriteLine("Message sent");
                                    // Send back a response. 
                                    Console.WriteLine($"Sending message.. {Encoding.UTF8.GetString(header)}");
                                    //sw.Write(data);
                                    //sw.Flush();
                                    File.WriteAllText("payload.txt", data);
                                    break;
                                case "/DATABASE.XML":
                                    XmlDocument xml = new XmlDocument();
                                    XmlDeclaration xmlDeclaration = xml.CreateXmlDeclaration("1.0", "UTF-8", null);
                                    XmlElement root = xml.DocumentElement;
                                    xml.InsertBefore(xmlDeclaration, root);
                                    XmlElement items = xml.CreateElement(string.Empty, "fingers", string.Empty);
                                    xml.AppendChild(items);
                                    foreach (var finger in fingerAccounts)
                                    {
                                        XmlElement fingernode = xml.CreateElement(string.Empty, "finger", string.Empty);
                                        fingernode.AppendChild(xml.CreateElement(string.Empty, "Name", string.Empty)).InnerText = finger.Name;
                                        fingernode.AppendChild(xml.CreateElement(string.Empty, "LogState", string.Empty)).InnerText = finger.loggedIn.ToString();
                                        if (finger.loggedIn)
                                        {
                                            fingernode.AppendChild(xml.CreateElement(string.Empty, "CurrentTime", string.Empty)).InnerText = Extensions.ToReadableString(finger.CurrentTime);
                                        }
                                        else
                                        {
                                            fingernode.AppendChild(xml.CreateElement(string.Empty, "CurrentTime", string.Empty)).InnerText = "n/a";
                                        }
                                            fingernode.AppendChild(xml.CreateElement(string.Empty, "TotalTime", string.Empty)).InnerText = Extensions.ToReadableString(finger.TotalTime);
                                        
                                        items.AppendChild(fingernode);
                                    }
                                    var memstr = new MemoryStream();
                                    xml.Save(memstr);
                                    byte[] __payLoad = memstr.ToArray();
                                    byte[] __header = Encoding.UTF8.GetBytes(WebUtility.HtmlEncode("HTTP/2.0 200 OK\r\ncontent-type: text/xml; charset=utf-8\r\ncontent-length: " + __payLoad.Length + "\r\n\r\n"));
                                    sw.Write(Encoding.UTF8.GetChars(__header));
                                    sw.Flush();
                                    sw.Write(Encoding.UTF8.GetChars(__payLoad));
                                    sw.Flush();
                                    Console.WriteLine($"Sending message.. {Encoding.UTF8.GetString(__payLoad)}");                                   
                                    break;
                                default:
                                    if (File.Exists(request.TrimStart('/')))
                                    {
                                        byte[] _payLoad = Encoding.UTF8.GetBytes(File.ReadAllText(request.TrimStart('/')));
                                        byte[] _header = Encoding.UTF8.GetBytes(WebUtility.HtmlEncode("HTTP/2.0 200 OK\r\ncontent-type: text/html; charset=utf-8\r\ncontent-length: " + _payLoad.Length + "\r\n\r\n"));

                                        var _buff = _header.ToList();
                                        _buff.AddRange(_payLoad.ToList());
                                        byte[] _buffer = _buff.ToArray();
                                        //sw.Write(Encoding.UTF8.GetChars(buffer));

                                        sw.Write(Encoding.UTF8.GetChars(_header));
                                        sw.Flush();
                                        sw.Write(Encoding.UTF8.GetChars(_payLoad));

                                        sw.Flush();
                                        Console.WriteLine("Message sent");
                                        // Send back a response. 
                                        Console.WriteLine($"Sending message.. {Encoding.UTF8.GetString(_header)}");
                                        //sw.Write(data);
                                        //sw.Flush();
                                        File.WriteAllText("payload.txt", data);
                                        break;
                                    }
                                    break;
                            }
                        }

                        break;
                    }
                    //sw.Close();

                }
                //sw.Write(Encoding.UTF8.GetChars(payLoad));

                //sw.Flush();
                //sw.Dispose();
                sw.Close();

                //byte[] payLoad = Encoding.UTF8.GetBytes(WebUtility.HtmlEncode(File.ReadAllText("index.html")));
                //byte[] header = Encoding.UTF8.GetBytes(WebUtility.HtmlEncode("HTTP/2.0 200 OK\r\ncontent-type: text/html; charset=utf-8\r\ncontent-length: " + payLoad.Length + ""));
                //var buff = header.ToList();
                //buff.AddRange(payLoad.ToList());
                //byte[] buffer = buff.ToArray();
                ////sw.Write(Encoding.UTF8.GetChars(buffer));
                //sw.Write(Encoding.UTF8.GetChars(header));                
                //sw.Flush();
                //sw.Write(Encoding.UTF8.GetChars(payLoad));
                //sw.Flush();

                //sw.Close();
            }
            //client.Flush();
            //client.Dispose();
            ////client.Close();
            //using (StreamWriter sw = new StreamWriter(client))
            //{
            //    //sw.Flush();
            //    byte[] payLoad = Encoding.UTF8.GetBytes(WebUtility.HtmlEncode(File.ReadAllText("index.html")));
            //    //byte[] header = Encoding.UTF8.GetBytes(WebUtility.HtmlEncode("HTTP/2.0 200 OK\ncontent-type: text/html; charset=utf-8\ncontent-length: " + payLoad.Length + "\ncontent: "));
            //    //var buff = header.ToList();
            //    //buff.AddRange(payLoad.ToList());
            //    //byte[] buffer = buff.ToArray();
            //    sw.Write(Encoding.UTF8.GetChars(payLoad));
            //    //sw.Write("\n");
            //    sw.Flush();
            //    //sw.Close();
            //}
            //client.Flush();
            //client.Close();
        }


        public static async Task HandleGET(Socket client)
        {

        }

        public static async Task HandlePOST(Socket client)
        {

        }
    }

    static class Extensions
    {
        public static string ToReadableString(this TimeSpan span)
        {
            string formatted = string.Format("{0}{1}{2}{3}",
                span.Duration().Days > 0 ? string.Format("{0:0} day{1}, ", span.Days, span.Days == 1 ? String.Empty : "s") : string.Empty,
                span.Duration().Hours > 0 ? string.Format("{0:0} hour{1}, ", span.Hours, span.Hours == 1 ? String.Empty : "s") : string.Empty,
                span.Duration().Minutes > 0 ? string.Format("{0:0} minute{1}, ", span.Minutes, span.Minutes == 1 ? String.Empty : "s") : string.Empty,
                span.Duration().Seconds > 0 ? string.Format("{0:0} second{1}", span.Seconds, span.Seconds == 1 ? String.Empty : "s") : string.Empty);

            if (formatted.EndsWith(", ")) formatted = formatted.Substring(0, formatted.Length - 2);

            if (string.IsNullOrEmpty(formatted)) formatted = "0 seconds";

            return formatted;
        }
    }
}
